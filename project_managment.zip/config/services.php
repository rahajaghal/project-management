<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],
    'google' => [
        'client_id' => '464070922557-l1rb5b94p56m2hl7jv6r2n0jpekkl9k8.apps.googleusercontent.com',
        'client_secret' =>'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',
        'redirect' => 'http://127.0.0.1:8000/auth/google/callback',
    ],
    'github' => [
        'client_id' => 'Ov23lim8swDSxiUrcs0z',
        'client_secret' =>'7e0c02ca265023af4a8aeef58f26ba61fc280f22',
        'redirect' => 'http://127.0.0.1:8000/auth/github/callback',
    ],

];
