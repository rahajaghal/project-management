<?php

return [
    "priority" => [
        "Low" => "Low",
        "Mid" => "Mid",
        "High" => "High"
    ],

];
